import Menu from "./menu";
import { Link } from "react-router-dom";
import Foter from "./Footer";
function Main() {
    return ( <div>
        <Menu></Menu>
        <br></br>
        <br></br>
        <br></br>
        <nav class="bg-dark navbar-dark">
  <div class="container">
  </div>
  </nav>
   <section id="header" class="jumbotron text-center">
     <h1 class="display-3">BUYING WEBSITES</h1>
     <p class="lead">“To give real service, you must add something which cannot be bought or measured with money, and that is sincerity and integrity.”</p>
     
</section>
  
<section id="gallery">
  <div class="container">
    <div class="row">
    <div class="col-lg-4 mb-4">
    <div class="card">
      <img src="app1.jpg" alt="" class="card-img-top"/>
      <div class="card-body">
        <h5 class="card-title">Data Science</h5>
        <p class="card-text">“In the world of successful people, there’s nothing like weekends… If you want to get rich and stay rich, then you need to shun this TGIF notion. Every day is an opportunity you can’t afford to miss.” - Ajaero Tony Martins, entrepreneur and investor</p>
       <a href="" class="btn btn-outline-success btn-sm">Read More</a>
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
      </div>
     </div>
    </div>
  <div class="col-lg-4 mb-4">
  <div class="card">
      <img src="app2.jpeg" alt="" class="card-img-top"/>
      <div class="card-body">
        <h5 class="card-title">Online Marketing</h5>
        <p class="card-text">“Approach each customer with the idea of helping him or her to solve a problem or achieve a goal, not of selling a product or service.” - Brian Tracy, motivational speaker and self-development author</p>
       <a href="" class="btn btn-outline-success btn-sm">Read More</a>
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
      </div>
      </div>
    </div>
    <div class="col-lg-4 mb-4">
    <div class="card">
      <img src="app3.jpeg" alt="" class="card-img-top"/>
      <div class="card-body">
        <h5 class="card-title">WEBSITES</h5>
        <p class="card-text">"Take up one idea. Make that one idea your life -- think of it, dream of it, live on that idea. Let the brain, muscles, nerves, every part of your body, be full of that idea, and just leave every other idea alone. This is the way to success."</p>
       <a href="" class="btn btn-outline-success btn-sm">Read More</a>
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
      </div>
     </div>
    </div>
  </div>
</div>
</section>
<div>
<img src="app6.jpeg" class="img-fluid" alt="Responsive image" style={{marginLeft:"110px"}}></img>

<p class="lead" style={{marginLeft:"250px",marginTop:"70px"}}>“As data and science become more accessible and more the production of software and AI,<br></br> human creativity is becoming a more valuable commodity.”</p>
<section id="header" class="jumbotron text-center" style={{marginTop:"40px"}}>
     
     
</section>
  
<section id="gallery">
  <div class="container">
    <div class="row">
    <div class="col-lg-4 mb-4">
    <div class="card">
      <img src="ma1.jpg" alt="" class="card-img-top"/>
      <div class="card-body">
      <Link to="website" style={{textDecoration:"none"}}>  <h5 class="card-title">WEBSITES</h5></Link>
       
       
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
      </div>
     </div>
    </div>
  <div class="col-lg-4 mb-4">
  <div class="card">
      <img src="ma22.jpg" alt="" class="card-img-top"/>
      <div class="card-body">
        <h5 class="card-title"><Link to="/application" style={{textDecoration:"none"}}>APPLICATIONS</Link></h5>
        
       
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
      </div>
      </div>
    </div>
    <div class="col-lg-4 mb-4">
    <div class="card">
      <img src="ma3.png" alt="" class="card-img-top"/>
      <div class="card-body">
       <Link to="/mapp" style={{textDecoration:"none"}}> <h5 class="card-title">MOBILE APPS</h5></Link>
        
       
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
      </div>
     </div>
    </div>
  </div>
</div>
</section>
</div>
<div>
<p class="lead" style={{marginLeft:"250px"}}>Programming today is a race between software engineers striving to build bigger and <br></br>better idiot-proof programs and the Universe trying to produce bigger and better idiots.</p>
<h2 class="display-3" style={{marginLeft:"300px",marginTop:"60px"}}>Popular Monetizations</h2>
<p class="lead" style={{marginLeft:"250px",marginTop:"60px"}}>Explore an exclusive selection of established online businesses for sale <br></br>by selecting a category you are interested in below.</p>

</div>
<div>
<section id="header" class="jumbotron text-center">
     
</section>
  
<section id="gallery">
  <div class="container">
    <div class="row">
    <div class="col-lg-4 mb-4">
    <div class="card">
    <Link>     <img src="aa1.JPG" alt="" class="card-img-top" /></Link>
      
     </div>
    </div>
  <div class="col-lg-4 mb-4">
  <div class="card">
  <Link>   <img src="aa2.JPG" alt="" class="card-img-top"/></Link>
      
      </div>
    </div>
    <div class="col-lg-4 mb-4">
    <div class="card">
    <Link>  <img src="aa3.JPG" alt="" class="card-img-top"/></Link>
      
     </div>
    </div>
  </div>
</div>
</section>
<section id="gallery">
  <div class="container">
    <div class="row">
    <div class="col-lg-4 mb-4">
    <div class="card">
    <Link>     <img src="aa4.JPG" alt="" class="card-img-top" /></Link>
      
     </div>
    </div>
  <div class="col-lg-4 mb-4">
  <div class="card">
  <Link>   <img src="aa5.JPG" alt="" class="card-img-top"/></Link>
      
      </div>
    </div>
    <div class="col-lg-4 mb-4">
    <div class="card">
    <Link>  <img src="aa6.JPG" alt="" class="card-img-top"/></Link>
      
     </div>
    </div>
  </div>
</div>
</section>
<section id="gallery">
  <div class="container">
    <div class="row">
    <div class="col-lg-4 mb-4">
    <div class="card">
    <Link>     <img src="aa7.JPG" alt="" class="card-img-top" /></Link>
      
     </div>
    </div>
  <div class="col-lg-4 mb-4">
  <div class="card">
  <Link>   <img src="aa8.JPG" alt="" class="card-img-top"/></Link>
      
      </div>
    </div>
    <div class="col-lg-4 mb-4">
    <div class="card">
    <Link>  <img src="aa2.JPG" alt="" class="card-img-top"/></Link>
      
     </div>
    </div>
  </div>
</div>
</section>
<Foter></Foter>
</div>
    </div>);
}

export default Main;