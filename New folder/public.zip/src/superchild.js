import { useContext} from "react";
import {info} from "./context";
function Super() {
    const{appColor,Day}=useContext(info);
    const day = "Sunday";
    return (
        <div>
<h2 style={{color:appColor}}> super Child component</h2>
<button className="btn btn-primary" onClick={()=>Day(day)}>Click</button>
        </div>
      );}

export default Super;