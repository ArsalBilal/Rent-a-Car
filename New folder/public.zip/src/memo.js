import { useState,useMemo } from "react";
 function Mem() {
    const [state,setstate]=useState(0);
    const [state1,setstate1]=useState(10);
     const memo = useMemo(function multicount(){
         console.warn("multicount");
         return state*5
     },[state]);
    return ( 
    <div >
    <h1>useMemo react hook</h1>
    <h2>item:{state}</h2>
    <h2>count:{state1}</h2>
     <h2>{memo}</h2> 
    <button onClick={()=>setstate(state+1)}>update count</button>
    <button onClick={()=>setstate1(state1*10)}>update item</button>
    </div> );
}
export default Mem;