import { useState,createContext } from "react";
import Child from "./child";
export const info=createContext();
function Context() {
    const[color,setColor]=useState("green");
    const[day,setDay]=useState("Wednesday");
    const getDay = (item) => {
        setDay(item);
    }
     
    
    return (
    <info.Provider value={{appColor:color,Day:getDay}}>
    <div>
        <h1>hello world it is {day}</h1>
        <Child/>
        
    </div> 
    </info.Provider> );
}

export default Context;