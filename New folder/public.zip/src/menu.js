import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { Link,useNavigate } from 'react-router-dom';
 
function Menu() {
  const navigate =useNavigate()
  function gotosignin(){
    navigate("/signup")
  }
  function gotologin(){
    navigate("/login")
  }
  function gotomarketing(){
    navigate("/marketing")
  }
  function gotoselling(){
    navigate("/seller")
  }
  function gotoabout(){
    navigate("/about")
  }
    return (  
        <div>
            <Navbar fixed="top" collapseOnSelect expand="lg" bg="dark" variant="dark">
      <Container>
      <Link to="/" style={{textDecoration:"none"}}>  <Navbar.Brand href="#home" >Web Broker</Navbar.Brand></Link>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link href="#Marketing"><button type="button" class="btn btn-secondary" onClick={gotomarketing}>Marketing</button></Nav.Link>
            <Nav.Link href="#Seller"><button type="button" class="btn btn-secondary" onClick={gotoselling}>Selling</button></Nav.Link>
            <NavDropdown title="Company" id="collasible-nav-dropdown">
              <NavDropdown.Item href="#about"><button type="button" class="btn btn-secondary" onClick={gotoabout}>About Us</button></NavDropdown.Item>
              <NavDropdown.Item href="#action/3.2">
              <button type="button" class="btn btn-secondary">Score Board</button>
              </NavDropdown.Item>
              <NavDropdown.Item href="#Blog"><button type="button" class="btn btn-secondary">Blog</button></NavDropdown.Item>
             
              
            </NavDropdown>
          </Nav>
          <Nav>
            <Nav.Link href="signup"><button type="button" class="btn btn-secondary" onClick={gotosignin}>Sign In</button></Nav.Link>
            <Nav.Link eventKey={2} href="#login">
            <button type="button" class="btn btn-secondary"npm onClick={gotologin}>Login</button>
            </Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
        </div>
    );
}

export default Menu;