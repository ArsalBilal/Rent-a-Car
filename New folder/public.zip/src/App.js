import {Routes, Route} from 'react-router-dom';

import Background from "./backgound";
import Seller from "./seller";
import Signup from "./signup";
import Login from "./login";
import About from './aboutus';
import Marketing1 from './marketing';
import Main from './main';
import Websites from './websites';
import Application from './application';
import Mobileapp from './mapp';






function App() {
  return (
    <div>
      
      <Routes>
      <Route path="/" element={<Main/>} />
      <Route path="/signup" element={<Signup/>} />
      <Route path="/login" element={<Login/>} />
      <Route path="/seller" element={<Seller/>} />
      <Route path="/marketing" element={<Marketing1/>} />
      <Route path="/about" element={<About/>} />
      <Route path="/website" element={<Websites/>} />
      <Route path="/application" element={<Application/>} />
      <Route path="/mapp" element={<Mobileapp/>} />
      </Routes>
    </div>
  );
}

export default App;
