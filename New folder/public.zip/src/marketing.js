import { useState } from "react";
import Foter from "./Footer";
import Menu from "./menu";
import { Link } from "react-router-dom";
function Marketing1() {
    const[card,setcard]= useState([
        {picture:"https://st.hzcdn.com/fimgs/fbe17faa05c62f83_9184-w360-h360-b0-p0--.jpg",name:"Home, Design", price:"Price :$2,945,536.00",Revenue:"Revenue  :     $210,111.00",NetProfit: "Net Profit  : $2,945,536.00"}
      ,{picture:"https://img.freepik.com/free-photo/golden-gifts-with-white-tie_1220-565.jpg?size=626&ext=jpg",name:"Romance, Occasions & Gifts", price:"Price :$2,157,715.00",Revenue:"Revenue  :     $154,178.00",NetProfit: "Net Profit  : $53,943.00"}
       ,{picture:"https://st.hzcdn.com/fimgs/1f31071605356ef0_4440-w360-h360-b0-p0--.jpg",name:"Home", price:"Price :$1,399,826.00",Revenue:"Revenue  :     $148,385.00",NetProfit: "Net Profit  : $30,431.00"},{picture:"https://st.hzcdn.com/fimgs/fbe17faa05c62f83_9184-w360-h360-b0-p0--.jpg",name:"Home, Design", price:"Price :$2,945,536.00",Revenue:"Revenue  :     $210,111.00",NetProfit: "Net Profit  : $2,945,536.00"}
       ,{picture:"https://img.freepik.com/free-photo/golden-gifts-with-white-tie_1220-565.jpg?size=626&ext=jpg",name:"Romance, Occasions & Gifts", price:"Price :$2,157,715.00",Revenue:"Revenue  :     $154,178.00",NetProfit: "Net Profit  : $53,943.00"}
        ,{picture:"https://st.hzcdn.com/fimgs/1f31071605356ef0_4440-w360-h360-b0-p0--.jpg",name:"Home", price:"Price :$1,399,826.00",Revenue:"Revenue  :     $148,385.00",NetProfit: "Net Profit  : $30,431.00"},{picture:"https://st.hzcdn.com/fimgs/fbe17faa05c62f83_9184-w360-h360-b0-p0--.jpg",name:"Home, Design", price:"Price :$2,945,536.00",Revenue:"Revenue  :     $210,111.00",NetProfit: "Net Profit  : $2,945,536.00"}
        ,{picture:"https://img.freepik.com/free-photo/golden-gifts-with-white-tie_1220-565.jpg?size=626&ext=jpg",name:"Romance, Occasions & Gifts", price:"Price :$2,157,715.00",Revenue:"Revenue  :     $154,178.00",NetProfit: "Net Profit  : $53,943.00"}
         ,{picture:"https://st.hzcdn.com/fimgs/1f31071605356ef0_4440-w360-h360-b0-p0--.jpg",name:"Home", price:"Price :$1,399,826.00",Revenue:"Revenue  :     $148,385.00",NetProfit: "Net Profit  : $30,431.00"}
       
      ])
     
    return (
        <div>
            <Menu></Menu>
            <br></br> 
            <br></br> 
            
            <div style={{background:"#EEEEEE"}}>
            <h1 class="display-3" style={{marginTop:"20px",marginLeft:"350px"}}>BUYING WEBSITES</h1>
     <p class="lead" style={{marginLeft:"100px"}}>“To give real service, you must add something which cannot be bought or measured with money, and that is sincerity and integrity.”</p>
     </div>  
            <section id="gallery" style={{background:"#EEEEEE"}} >
  <div class="container" style={{background:"#EEEEEE"}}>
    <div class="row">
    <div class="col-lg-4 mb-4">
    <div class="card">
      <img src="ma1.jpg" alt="" class="card-img-top"/>
      <div class="card-body">
      <Link to="website" style={{textDecoration:"none"}}>  <h5 class="card-title">WEBSITES</h5></Link>
       
       
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
      </div>
     </div>
    </div>
  <div class="col-lg-4 mb-4">
  <div class="card">
      <img src="ma22.jpg" alt="" class="card-img-top"/>
      <div class="card-body">
        <h5 class="card-title"><Link to="/application" style={{textDecoration:"none"}}>APPLICATIONS</Link></h5>
        
       
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
      </div>
      </div>
    </div>
    <div class="col-lg-4 mb-4">
    <div class="card">
      <img src="ma3.png" alt="" class="card-img-top"/>
      <div class="card-body">
       <Link to="/mapp" style={{textDecoration:"none"}}> <h5 class="card-title">MOBILE APPS</h5></Link>
        
       
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
        <a href="" class="btn btn-outline-danger btn-sm"><i class="far fa-heart"></i></a>
      </div>
     </div>
    </div>
  </div>
</div>
</section>
            <div style={{background:"#EEEEEE"}}>
            <h1 class="display-3" style={{marginTop:"20px",marginLeft:"350px"}}>BUYING WEBSITES</h1>
     <p class="lead" style={{marginLeft:"100px"}}>“To give real service, you must add something which cannot be bought or measured with money, and that is sincerity and integrity.”</p>
     </div>   
                {card.map((item)=>
(
  <div style={{background:"#EEEEEE",marginTop:"-16px"}}>
    <div class="card" style={{background:"#BBDEFB",height:"650px",width:"500px",marginLeft:"400px" }}>
    <img class="card-img" src={item.picture} alt="Card image cap" style={{width:"500px",height:"400px",}}></img>
    <div class="card-body" style={{}}>
      <h5 class="card-title"><h4 style={{color:"black"}}>{item.name}<br></br><br></br> {item.price}</h4></h5>
      <p class="card-text"><h4 style={{color:"black"}}>{item.Revenue}<br></br></h4><h4 style={{color:"black"}}>{item.NetProfit}</h4></p>
      <button type="button" class="btn btn-primary">Buy</button>
      <br></br>
    </div>
    </div>
    </div>
    ))
}

<Foter></Foter>
        </div>
        
      );
}

export default Marketing1;