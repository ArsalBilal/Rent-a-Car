import Menu from "./menu";
import { useState } from "react";
import Foter from "./Footer";
function Application() {
    const [west,setwest]=useState([
        {image:"./ap1.jpg " ,title:"Medical Store System",price:"$3,054,148.00",},
        {image:"./ap2.png" ,title:"Adobe Reader",price:"$676,847.00",},
       {image:"./ap3.png" ,title:"Brave Browser",price:"$501,603.00",},
       {image:"./ap4.png " ,title:"Window 10",price:"$406,129.00",}
      
       ]);
    return ( 
        
    <div>
        <Menu></Menu>
        <h4 class="display-3" style={{marginTop:"80px",marginLeft:"200px"}}>DESKTOPS APPLICATIONS LIST</h4>
        <div  style={{display:"flex",flexDirection:"row",position:"static",marginTop:"20px"}}>
            
{
                west.map((setwest,key)=>(

                    <section id="gallery">
                    <div class="container" >
                      <div class="row" >
                      <div class="col-lg-4 mb-4">
                      <div class="card" style={{width:"300px"}}>
                        <img src={setwest.image} alt="" class="card-img-top"/>
                        <div class="card-body">
                          <h5 class="card-title">{setwest.title}</h5>
                          <p class="card-text">{setwest.price}</p>
                          <button type="button" class="btn btn-primary">Buy</button>
                          
                        </div>
                       </div>
                      </div>
                      </div>
                      </div>
                      </section>
  ))
}
</div>
<div  style={{display:"flex",flexDirection:"row",position:"static",marginTop:"20px"}}>
{
                west.map((setwest,key)=>(

                    <section id="gallery">
                    <div class="container" >
                      <div class="row" >
                      <div class="col-lg-4 mb-4">
                      <div class="card" style={{width:"300px"}}>
                        <img src={setwest.image} alt="" class="card-img-top"/>
                        <div class="card-body">
                          <h5 class="card-title">{setwest.title}</h5>
                          <p class="card-text">{setwest.price}</p>
                          <button type="button" class="btn btn-primary">Buy</button>
                          
                        </div>
                       </div>
                      </div>
                      </div>
                      </div>
                      </section>
  ))
}
</div>
<div  style={{display:"flex",flexDirection:"row",position:"static",marginTop:"20px"}}>
{
                west.map((setwest,key)=>(

                    <section id="gallery">
                    <div class="container" >
                      <div class="row" >
                      <div class="col-lg-4 mb-4">
                      <div class="card" style={{width:"300px"}}>
                        <img src={setwest.image} alt="" class="card-img-top"/>
                        <div class="card-body">
                          <h5 class="card-title">{setwest.title}</h5>
                          <p class="card-text">{setwest.price}</p>
                          <button type="button" class="btn btn-primary">Buy</button>
                          
                        </div>
                       </div>
                      </div>
                      </div>
                      </div>
                      </section>
  ))
}
</div>
<div  style={{display:"flex",flexDirection:"row",position:"static",marginTop:"20px"}}>
{
                west.map((setwest,key)=>(

                    <section id="gallery">
                    <div class="container" >
                      <div class="row" >
                      <div class="col-lg-4 mb-4">
                      <div class="card" style={{width:"300px"}}>
                        <img src={setwest.image} alt="" class="card-img-top"/>
                        <div class="card-body">
                          <h5 class="card-title">{setwest.title}</h5>
                          <p class="card-text">{setwest.price}</p>
                          <button type="button" class="btn btn-primary">Buy</button>
                          
                        </div>
                       </div>
                      </div>
                      </div>
                      </div>
                      </section>
  ))
}
</div>
<div  style={{display:"flex",flexDirection:"row",position:"static",marginTop:"20px"}}>
{
                west.map((setwest,key)=>(

                    <section id="gallery">
                    <div class="container" >
                      <div class="row" >
                      <div class="col-lg-4 mb-4">
                      <div class="card" style={{width:"300px"}}>
                        <img src={setwest.image} alt="" class="card-img-top"/>
                        <div class="card-body">
                          <h5 class="card-title">{setwest.title}</h5>
                          <p class="card-text">{setwest.price}</p>
                          <button type="button" class="btn btn-primary">Buy</button>
                          
                        </div>
                       </div>
                      </div>
                      </div>
                      </div>
                      </section>
  ))
}
</div>
<img src="app6.jpeg" class="img-fluid" alt="Responsive image" style={{marginLeft:"110px"}}></img>
<Foter></Foter>
    </div> );
}

export default Application;