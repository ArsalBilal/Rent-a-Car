import { useState, useEffect, useRef } from "react";
import ReactDOM from "react-dom/client";
import { Link } from "react-router-dom";
import Mem from "./memo";
import Menu from "./menu";
import Super from "./superchild";
function About() {
  const [inputValue, setInputValue] = useState("");
  const previousInputValue = useRef("");

  useEffect(() => {
    previousInputValue.current = inputValue;
  }, [inputValue]);
    return ( <div>
      <Menu></Menu>
      <Link><img src="about.JPG" class="img-fluid" alt="Responsive image"style={{marginLeft:"0px"}}></img></Link>
    
    
    </div> );
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<   About />);
export default About;