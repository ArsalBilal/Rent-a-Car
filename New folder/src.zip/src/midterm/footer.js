import React from 'react'
import'./footer.css'
 const Footer = () => {
  return (
    <div>
        

        
         <div className="footer"> 
         
       <table> <h4  className="footer1">
       <img  src="/pic/sponser.png" alt=""  /></h4>
        <th className="heading"></th>
     
        <tr>
          
        <td>
        <h2 className="mar"></h2> <h3 className="mar2"><h4  className="heading2">EXPLORE</h4>
          About FIFA<h4>Competitions</h4><h4>women football</h4><h4>Impact</h4><h4>  <img className="pic" src="/pic/logo.jpg" alt=""  />
          </h4></h3>
        </td>
       
        
          <td className="heading3" >
            <h4 className="visit">Also Visit</h4>
            <h4 className="mar2"><h4 >All storis and topics</h4><h4>official documents</h4><h4>JObs careers</h4>
            <h4>contact FIFA</h4></h4>
          </td>

          
          </tr>
        </table>
        </div>
        </div>
    
  )
}
export default Footer;