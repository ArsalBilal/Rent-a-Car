import React from 'react'
import'./men2style.css'

const Men2 = () => {
  return (
    <div><div className="line"></div>
  <nav className="logo1">
       
        
      
      
       <label className="logo2"></label>
       <ul  className="active4">
         
           <li>Tournaments FIFA</li>
           <li>About FIFA</li>
           
        
         
            <li>Women's football</li>
            <li> Social Impact</li>
            <li>Football development</li>
            <li> Technical</li>
            <li> World Ranking</li>
          
       </ul>
   
   </nav>
    </div>
  )
}
export default Men2;