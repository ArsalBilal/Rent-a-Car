import { Link } from "react-router-dom";
function Foter() {
    return (  <div>
        <div style={{Background:"Black",height:"2px"}}></div>
<div  class="card-body">
<div class="row">
    <div class="col-3" style={{}}>
     <Link style={{textDecoration: 'none'}}>   <h4 style={{marginLeft:"70px",marginTop:"30px"}}>EXPLORE</h4>
        <p style={{fontSize:18,marginLeft:"60px"}}>Competitions</p>
        <p style={{fontSize:18,marginLeft:"60px"}}>About Website</p>
        <p style={{fontSize:18,marginLeft:"60px"}}>Others</p>
        <p style={{fontSize:18,marginLeft:"60px"}}>Social Impact</p>
        <p style={{fontSize:18,marginLeft:"60px"}}> Development</p>
        <p style={{fontSize:18,marginLeft:"60px"}}>Technical</p>
        <p style={{fontSize:18,marginLeft:"60px"}}>Legal & Compliance</p>
        <p style={{fontSize:18,marginLeft:"60px"}}>World ranking</p></Link>
    </div>
    <div class="col-6" style={{}}>
    <Link style={{textDecoration: 'none'}}> <h4 style={{marginLeft:"70px",marginTop:"30px"}}>ALSO VISIT</h4>
        <p style={{fontSize:18,marginLeft:"60px"}}>All stories & topics</p>
        <p style={{fontSize:18,marginLeft:"60px"}}>Official documents</p>
        <p style={{fontSize:18,marginLeft:"60px"}}>Jobs & Careers</p>
        <p style={{fontSize:18,marginLeft:"60px"}}>Contact Us</p></Link>
    </div>
    </div>
    </div>
    </div>);
}

export default Foter;