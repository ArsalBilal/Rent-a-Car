import Menu from "./menu";
import Foter from "./Footer";
function Seller() {
    return (  <div>
        <Menu></Menu>
        <br></br>
        <br></br>
        <br></br>

        <img src="selling.JPG" class="img-fluid" alt="Responsive image"></img>
        <img src="selling2.JPG" class="img-fluid" alt="Responsive image"></img>
        <img src="selling3.JPG" class="img-fluid" alt="Responsive image"></img>
        <img src="selling4.JPG" class="img-fluid" alt="Responsive image"></img>
        <img src="selling5.JPG" class="img-fluid" alt="Responsive image"></img>
        <img src="caro1.jpg" class="img-fluid" alt="Responsive image" style={{marginLeft:"350px"}}></img>
        <br></br>
        <br></br>
        <br></br>
      <Foter></Foter>
    </div>);
}

export default Seller;