import { useContext} from "react";
import Super from "./superchild";
import {info} from "./context";
function Child() {
    const{appColor}=useContext(info);
    return (
        <div>
<h2 style={{color:appColor}}>Child component</h2>
<Super/>
        </div>
      );
}

export default Child;