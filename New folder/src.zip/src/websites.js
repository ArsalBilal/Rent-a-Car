import { useState } from "react";
import Menu from "./menu";
function Websites() {
    const [west,setwest]=useState([
        {image:"./we1.jpg " ,title:"Beauty, Personal Care",price:"$3,054,148.00",},
        {image:"./we2.png" ,title:"Automotive, Electronics",price:"$676,847.00",},
       {image:"./we3.jpg" ,title:"Art, Home, Design",price:"$501,603.00",},
       {image:"./we4.jpg " ,title:"Information, Medical, Employment",price:"$406,129.00",},{image:"./we1.jpg " ,title:"Beauty, Personal Care",price:"$3,054,148.00",},
       {image:"./we2.png" ,title:"Automotive, Electronics",price:"$676,847.00",},
      {image:"./we3.jpg" ,title:"Art, Home, Design",price:"$501,603.00",},
      {image:"./we4.jpg " ,title:"Information, Medical, Employment",price:"$406,129.00",},{image:"./we1.jpg " ,title:"Beauty, Personal Care",price:"$3,054,148.00",},
      {image:"./we2.png" ,title:"Automotive, Electronics",price:"$676,847.00",},
     {image:"./we3.jpg" ,title:"Art, Home, Design",price:"$501,603.00",},
     {image:"./we4.jpg " ,title:"Information, Medical, Employment",price:"$406,129.00",},{image:"./we1.jpg " ,title:"Beauty, Personal Care",price:"$3,054,148.00",},
     {image:"./we2.png" ,title:"Automotive, Electronics",price:"$676,847.00",},
    {image:"./we3.jpg" ,title:"Art, Home, Design",price:"$501,603.00",},
    {image:"./we4.jpg " ,title:"Information, Medical, Employment",price:"$406,129.00",},{image:"./we1.jpg " ,title:"Beauty, Personal Care",price:"$3,054,148.00",},
    {image:"./we2.png" ,title:"Automotive, Electronics",price:"$676,847.00",},
   {image:"./we3.jpg" ,title:"Art, Home, Design",price:"$501,603.00",},
   {image:"./we4.jpg " ,title:"Information, Medical, Employment",price:"$406,129.00",},{image:"./we1.jpg " ,title:"Beauty, Personal Care",price:"$3,054,148.00",},
   {image:"./we2.png" ,title:"Automotive, Electronics",price:"$676,847.00",},
  {image:"./we3.jpg" ,title:"Art, Home, Design",price:"$501,603.00",},
  {image:"./we4.jpg " ,title:"Information, Medical, Employment",price:"$406,129.00",},{image:"./we1.jpg " ,title:"Beauty, Personal Care",price:"$3,054,148.00",},
  {image:"./we2.png" ,title:"Automotive, Electronics",price:"$676,847.00",},
 {image:"./we3.jpg" ,title:"Art, Home, Design",price:"$501,603.00",},
 {image:"./we4.jpg " ,title:"Information, Medical, Employment",price:"$406,129.00",}
       ]);
    return ( <div>
        <Menu></Menu>
        <h3 class="display-3" style={{marginTop:"80px",marginLeft:"400px"}}>WEBSITES LIST</h3>
        <div  style={{display:"flex",flexDirection:"row",position:"static",marginTop:"20px"}}>
{
                west.map((setwest,key)=>(

                    <section id="gallery">
                    <div class="container" >
                      <div class="row" >
                      <div class="col-lg-4 mb-4">
                      <div class="card" style={{width:"300px"}}>
                        <img src={setwest.image} alt="" class="card-img-top"/>
                        <div class="card-body">
                          <h5 class="card-title">{setwest.title}</h5>
                          <p class="card-text">{setwest.price}</p>
                          <button type="button" class="btn btn-primary">Buy</button>
                          
                        </div>
                       </div>
                      </div>
                      </div>
                      </div>
                      </section>
  ))
}
</div>
    </div> );
}

export default Websites;